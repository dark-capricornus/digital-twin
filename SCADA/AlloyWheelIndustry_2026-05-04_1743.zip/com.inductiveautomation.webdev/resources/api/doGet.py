def doGet(request, session):
   # =========================================================
    # RAW PLC TAG API (SCADA truth)
    # =========================================================

    tags = [
        # ---- PLC GLOBAL ----
        "[default]AlloyWheelManufacturingIndustry/PLC/Runtime/State",

        # ---- Furnace_01 ----
        "[default]AlloyWheelManufacturingIndustry/PLC/Furnace_01/Status/Temperature",
        "[default]AlloyWheelManufacturingIndustry/PLC/Furnace_01/Status/TargetTemp",
        "[default]AlloyWheelManufacturingIndustry/PLC/Furnace_01/Outputs/BurnerEnable",
        "[default]AlloyWheelManufacturingIndustry/PLC/Furnace_01/Status/OverTempAlarm",
        "[default]AlloyWheelManufacturingIndustry/PLC/Furnace_01/Status/State",

        # ---- LPDC_01 ----
        "[default]AlloyWheelManufacturingIndustry/PLC/LPDC_01/Status/PressurePSI",
        "[default]AlloyWheelManufacturingIndustry/PLC/LPDC_01/Status/CycleRunning",
        "[default]AlloyWheelManufacturingIndustry/PLC/LPDC_01/Status/Progress",
        "[default]AlloyWheelManufacturingIndustry/PLC/LPDC_01/Status/ProcessedCount",
        "[default]AlloyWheelManufacturingIndustry/PLC/LPDC_01/Status/State",

        # ---- CNC_01 ----
        "[default]AlloyWheelManufacturingIndustry/PLC/CNC_01/Status/SpindleRPM",
        "[default]AlloyWheelManufacturingIndustry/PLC/CNC_01/Status/Busy",
        "[default]AlloyWheelManufacturingIndustry/PLC/CNC_01/Status/Progress",
        "[default]AlloyWheelManufacturingIndustry/PLC/CNC_01/Status/ProcessedCount",
        "[default]AlloyWheelManufacturingIndustry/PLC/CNC_01/Status/State",

        # ---- Buffer_01 ----
        "[default]AlloyWheelManufacturingIndustry/PLC/Buffer_01/Status/PartCount",
        "[default]AlloyWheelManufacturingIndustry/PLC/Buffer_01/Status/Capacity",
        "[default]AlloyWheelManufacturingIndustry/PLC/Buffer_01/Status/Full",
        "[default]AlloyWheelManufacturingIndustry/PLC/Buffer_01/Status/Empty",
    
    	 "[default]AlloyWheelManufacturingIndustry/PLC/Degasser_01/kg_degassed"	
    ]

    values = system.tag.readBlocking(tags)

    raw_data = {}
    for i, tag in enumerate(tags):
        raw_data[tag.replace("[default]", "")] = {
            "value": values[i].value,
            "quality": str(values[i].quality),
            "timestamp": str(values[i].timestamp)
        }

    return {
        "json": {
            "source": "Ignition Gateway",
            "timestamp": system.date.now().toString(),
            "data": raw_data
        }
    }