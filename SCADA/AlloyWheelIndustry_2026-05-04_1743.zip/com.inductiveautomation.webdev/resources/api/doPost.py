def doPost(request, session):
