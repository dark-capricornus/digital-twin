def doGet(request, session):
 # =========================================================
    # Shared RAW PLC read function (single source of truth)
    # =========================================================
    def read_raw_plc_data():
        tags = [
            # ---- PLC GLOBAL ----
            "[default]AlloyWheelManufacturingIndustry/PLC/Runtime/State",

            # ---- Furnace_01 ----
            "[default]AlloyWheelManufacturingIndustry/PLC/Furnace_01/Status/Temperature",
            "[default]AlloyWheelManufacturingIndustry/PLC/Furnace_01/Status/TargetTemp",
            "[default]AlloyWheelManufacturingIndustry/PLC/Furnace_01/Outputs/BurnerEnable",
            "[default]AlloyWheelManufacturingIndustry/PLC/Furnace_01/Status/OverTempAlarm",
            "[default]AlloyWheelManufacturingIndustry/PLC/Furnace_01/Status/State",

            # ---- LPDC_01 ----
            "[default]AlloyWheelManufacturingIndustry/PLC/LPDC_01/Status/PressurePSI",
            "[default]AlloyWheelManufacturingIndustry/PLC/LPDC_01/Status/CycleRunning",
            "[default]AlloyWheelManufacturingIndustry/PLC/LPDC_01/Status/Progress",
            "[default]AlloyWheelManufacturingIndustry/PLC/LPDC_01/Status/ProcessedCount",
            "[default]AlloyWheelManufacturingIndustry/PLC/LPDC_01/Status/State",

            # ---- CNC_01 ----
            "[default]AlloyWheelManufacturingIndustry/PLC/CNC_01/Status/SpindleRPM",
            "[default]AlloyWheelManufacturingIndustry/PLC/CNC_01/Status/Busy",
            "[default]AlloyWheelManufacturingIndustry/PLC/CNC_01/Status/Progress",
            "[default]AlloyWheelManufacturingIndustry/PLC/CNC_01/Status/ProcessedCount",
            "[default]AlloyWheelManufacturingIndustry/PLC/CNC_01/Status/State",

            # ---- Buffer_01 ----
            "[default]AlloyWheelManufacturingIndustry/PLC/Buffer_01/Status/PartCount",
            "[default]AlloyWheelManufacturingIndustry/PLC/Buffer_01/Status/Capacity",
            "[default]AlloyWheelManufacturingIndustry/PLC/Buffer_01/Status/Full",
            "[default]AlloyWheelManufacturingIndustry/PLC/Buffer_01/Status/Empty",
            
            # ---- Degasser ----
            "[default]AlloywheelManufacturingIndustry/PLC/Degasser_01/kg_degassed"
        ]

        values = system.tag.readBlocking(tags)

        raw_data = {}
        for i, tag in enumerate(tags):
            raw_data[tag.replace("[default]", "")] = {
                "value": values[i].value,
                "quality": str(values[i].quality),
                "timestamp": str(values[i].timestamp)
            }

        return raw_data

    # =========================================================
    # NORMALIZATION LOGIC
    # =========================================================
    raw_data = read_raw_plc_data()

    devices = {}
    plc_state = None

    for path, payload in raw_data.items():
        parts = path.split("/")
        
        if len(parts) == 4 and parts[2] == "Runtime" and parts[3] == "State":
        	plc_state = payload["value"]
        	continue
		
        if len(parts) < 5:
            continue

        device = parts[2]
        section = parts[3]
        tag = parts[4]
        value = payload["value"]

        if device == "Runtime" and tag == "State":
            plc_state = value
            continue

        if device not in devices:
            devices[device] = {}

        if section == "Status" and tag == "State":
            devices[device]["status"] = str(value).upper()
            continue
        
        if device == "Degasser_01":
        	if tag == "kg_degassed":
        		devices[device]["count"] = value
        		
        if device == "Furnace_01":
            if tag == "Temperature":
                devices[device]["temperature"] = value
            elif tag == "TargetTemp":
                devices[device]["target_temp"] = value
            elif tag == "OverTempAlarm":
                devices[device]["overtemp_alarm"] = value
            elif tag == "BurnerEnable":
                devices[device]["burner_on"] = value

        elif device == "LPDC_01":
            if tag == "PressurePSI":
                devices[device]["pressure_psi"] = value
            elif tag == "CycleRunning":
                devices[device]["cycle_running"] = value
            elif tag == "Progress":
                devices[device]["progress"] = value
            elif tag == "ProcessedCount":
                devices[device]["processed_count"] = value

        elif device == "CNC_01":
            if tag == "SpindleRPM":
                devices[device]["spindle_rpm"] = value
            elif tag == "Busy":
                devices[device]["busy"] = value
            elif tag == "Progress":
                devices[device]["progress"] = value
            elif tag == "ProcessedCount":
                devices[device]["processed_count"] = value

        elif device == "Buffer_01":
            if tag == "PartCount":
                devices[device]["part_count"] = value
            elif tag == "Capacity":
                devices[device]["capacity"] = value
            elif tag == "Full":
                devices[device]["full"] = value
            elif tag == "Empty":
                devices[device]["empty"] = value

    return {
        "json": {
            "source": "Ignition WebDev Digital Twin",
            "timestamp": system.date.now().toString(),
            "plc_state": plc_state,
            "devices": devices
        }
    }